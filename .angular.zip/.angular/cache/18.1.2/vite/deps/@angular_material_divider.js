import {
  MatDivider,
  MatDividerModule
} from "./chunk-QLQREFZ2.js";
import "./chunk-GSA4QKZ5.js";
import "./chunk-TFHZLHOO.js";
import "./chunk-DYOHH5ZP.js";
import "./chunk-52CZFGXD.js";
import "./chunk-YTR4LZ5T.js";
export {
  MatDivider,
  MatDividerModule
};
//# sourceMappingURL=@angular_material_divider.js.map
