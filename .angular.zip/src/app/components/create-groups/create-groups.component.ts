import { Component } from '@angular/core';

@Component({
  selector: 'app-create-groups',
  standalone: true,
  imports: [],
  templateUrl: './create-groups.component.html',
  styleUrl: './create-groups.component.scss'
})
export class CreateGroupsComponent {

}
