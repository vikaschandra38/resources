import { Component } from '@angular/core';

@Component({
  selector: 'app-update-roles',
  standalone: true,
  imports: [],
  templateUrl: './update-roles.component.html',
  styleUrl: './update-roles.component.scss'
})
export class UpdateRolesComponent {

}
