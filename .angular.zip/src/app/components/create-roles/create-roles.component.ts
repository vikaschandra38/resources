import { Component } from '@angular/core';

@Component({
  selector: 'app-create-roles',
  standalone: true,
  imports: [],
  templateUrl: './create-roles.component.html',
  styleUrl: './create-roles.component.scss'
})
export class CreateRolesComponent {

}
