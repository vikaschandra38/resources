import { Component } from '@angular/core';

@Component({
  selector: 'app-update-application',
  standalone: true,
  imports: [],
  templateUrl: './update-application.component.html',
  styleUrl: './update-application.component.scss'
})
export class UpdateApplicationComponent {

}
