import { Component } from '@angular/core';

@Component({
  selector: 'app-create-users',
  standalone: true,
  imports: [],
  templateUrl: './create-users.component.html',
  styleUrl: './create-users.component.scss'
})
export class CreateUsersComponent {

}
