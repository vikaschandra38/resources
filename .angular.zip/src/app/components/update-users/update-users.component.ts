import { Component } from '@angular/core';

@Component({
  selector: 'app-update-users',
  standalone: true,
  imports: [],
  templateUrl: './update-users.component.html',
  styleUrl: './update-users.component.scss'
})
export class UpdateUsersComponent {

}
