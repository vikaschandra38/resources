import { Component } from '@angular/core';

@Component({
  selector: 'app-update-groups',
  standalone: true,
  imports: [],
  templateUrl: './update-groups.component.html',
  styleUrl: './update-groups.component.scss'
})
export class UpdateGroupsComponent {

}
