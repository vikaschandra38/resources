export interface Role {
  roleId: string;
  roleName: string;
  description: string;
}
