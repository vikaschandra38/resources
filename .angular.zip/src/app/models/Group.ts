export interface Group {
  groupId?: string;
  groupName: string;
  groupManager: string;
  groupMembers: string[];
  groupEmail: string;
}
